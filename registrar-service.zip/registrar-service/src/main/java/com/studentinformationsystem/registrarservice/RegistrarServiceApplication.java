package com.studentinformationsystem.registrarservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrarServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrarServiceApplication.class, args);
	}

}
